package zendesk.springboot.services;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import zendesk.mvc.model.Page;
import zendesk.mvc.model.Ticket;
import zendesk.mvc.model.User;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

@Controller
public class TicketController {

    private static final Logger LOGGER = LogManager.getLogger();
    private Page pages = new Page();
    private User user = new User();

    @GetMapping("/")
    public String getHomepage() {
        return "home";
    }

    @GetMapping("/2")
    public String getHomepage2() {
        return "home2";
    }

    @GetMapping("/tickets")
    public String getTicketsPagination(@RequestParam(value="before_cursor", required = false) String before_cursor,
            @RequestParam(value="size", required = false) String after_cursor,Model model){
        String uri = ""
        RestTemplate restTemplate = new RestTemplate();
        List<Ticket> tickets = new ArrayList<Ticket>();

        try {
            ResponseEntity<String> response = restTemplate.exchange(uri,
                    HttpMethod.GET, new HttpEntity<>(createHeaders(user.getEmail(), user.getPassword())),
                    String.class);
            JSONObject json = new JSONObject(response.getBody());
            JSONArray ticketsList = json.getJSONArray("tickets");
            JSONObject links = json.getJSONObject("links");

            for (Object ticket : ticketsList){
                tickets.add(Ticket.fromJSONObjectSpring((JSONObject) ticket));
            }
            pages.setNext(links.getString("next"));
            pages.setPrev(links.getString("prev"));
            model.addAttribute("tickets", tickets);
            return "tickets_viewer";
        } catch (HttpStatusCodeException e){
            return "unauthorized_alert";
        }
    }

    @PostMapping("/tickets")
    public String getTickets(@RequestParam String email, @RequestParam String password, Model model){
        String uri = "https://zcc-vi-vu.zendesk.com/api/v2/tickets?page[size]=25";
        RestTemplate restTemplate = new RestTemplate();
        List<Ticket> tickets = new ArrayList<Ticket>();
        user.setEmail(email);
        user.setPassword(password);

        try {
            ResponseEntity<String> response = restTemplate.exchange(uri,
                    HttpMethod.GET, new HttpEntity<>(createHeaders(email, password)),
                    String.class);
            JSONObject json = new JSONObject(response.getBody());
            JSONArray ticketsList = json.getJSONArray("tickets");
            JSONObject meta = json.getJSONObject("meta");

            for (Object ticket : ticketsList){
                tickets.add(Ticket.fromJSONObjectSpring((JSONObject) ticket));
            }
            LOGGER.info(json);
            model.addAttribute("pages", meta);
            model.addAttribute("tickets", tickets);
            return "tickets_viewer";
        } catch (HttpStatusCodeException e){
            return "unauthorized_alert";
        }
    }

    @PostMapping("/tickets/{id}")
    public String getTicketDetail(@RequestParam String email, @RequestParam String password,
                                  @RequestParam int ticketId, Model model) {
        String uri = "https://zcc-vi-vu.zendesk.com/api/v2/tickets/" + ticketId;
        RestTemplate restTemplate = new RestTemplate();
        try {
            ResponseEntity<String> response = restTemplate.exchange(uri,
                    HttpMethod.GET, new HttpEntity<>(createHeaders(email, password)),
                    String.class);
            JSONObject json = new JSONObject(response.getBody());
            JSONObject json2 = json.getJSONObject("ticket");
            Ticket ticket = Ticket.fromJSONObjectSpringWithDesc(json2);
            model.addAttribute("ticket", ticket);

            return "ticket_details";
        } catch (HttpStatusCodeException e) {
            return "unauthorized_alert";
        }
    }
    private HttpHeaders createHeaders(String username, String password) {
        return new HttpHeaders() {{
            String auth = username + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(
                    auth.getBytes(Charset.forName("US-ASCII")));
            String authHeader = "Basic " + new String(encodedAuth);
            set("Authorization", authHeader);
        }};
    }
}
