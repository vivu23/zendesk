package zendesk.mvc.model;


import org.json.JSONObject;

public class Ticket {
    private int id;
    private String subject;
    private String description;

    public Ticket(int id, String subject) {
        this.id = id;
        this.subject = subject;
    }

    public Ticket(int id, String subject, String description) {
        this.id = id;
        this.subject = subject;
        this.description = description;
    }

    //convert from JSON to Object
    public static Ticket fromJSONObjectSpring(JSONObject json) {
        try {
            Ticket ticket = new Ticket(json.getInt("id"), json.getString("subject"));
            return ticket;
        } catch(Exception e) {
            throw new IllegalArgumentException("Unable to parse ticket from provided json: " + json.toString());
        }
    }

    //convert from JSON to Object
    public static Ticket fromJSONObjectSpringWithDesc(JSONObject json) {
        try {
            Ticket ticket = new Ticket(json.getInt("id"), json.getString("subject"),
                    json.getString("description"));
            return ticket;
        } catch(Exception e) {
            throw new IllegalArgumentException("Unable to parse ticket from provided json: " + json.toString());
        }
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id=" + id +
                ", subject='" + subject + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
